import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:peso_y_masa_muscular/bloc/indicators_bloc.dart';
import 'package:peso_y_masa_muscular/model/indicator.dart';

class IndicatorForm extends StatefulWidget {
  final BuildContext context;

  IndicatorForm({this.context});

  @override
  State<StatefulWidget> createState() => _IndicatorFormState(context: context);
}

class _IndicatorFormState extends State<IndicatorForm> {
  BuildContext context;
  final _formKey = GlobalKey<FormState>();
  double weight = 0;
  double imc = 0;
  double muscle = 0;
  double fat = 0;
  FocusNode _focusNodeWeight;
  FocusNode _focusNodeImc;
  FocusNode _focusNodeMuscle;
  FocusNode _focusNodeFat;
  Expanded _textFormWeight;
  Expanded _textFormImc;
  Expanded _textFormMuscle;
  Expanded _textFormFat;
  TextEditingController _weightController;
  TextEditingController _imcController;
  TextEditingController _muscleController;
  TextEditingController _fatController;

  _IndicatorFormState({this.context});

  @override
  void initState() {
    super.initState();
    _focusNodeWeight = FocusNode();
    _focusNodeImc = FocusNode();
    _focusNodeMuscle = FocusNode();
    _focusNodeFat = FocusNode();
    _weightController = TextEditingController();
    _imcController = TextEditingController();
    _muscleController = TextEditingController();
    _fatController = TextEditingController();
    _textFormWeight = _getTextField('Peso (kg)', _focusNodeWeight, _focusNodeImc, _weightController, _imcController);
    _textFormImc = _getTextField('IMC', _focusNodeImc, _focusNodeMuscle, _imcController, _muscleController);
    _textFormMuscle = _getTextField('% de músculo', _focusNodeMuscle, _focusNodeFat, _muscleController, _fatController);
    _textFormFat = _getTextField('% de grasa', _focusNodeFat, _focusNodeWeight, _fatController, _weightController);
  }

  @override
  void dispose() {
    _focusNodeWeight.dispose();
    _focusNodeImc.dispose();
    _focusNodeMuscle.dispose();
    _focusNodeFat.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Nueva medición'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: <Widget>[
              Row(
                children: <Widget>[
                  _textFormWeight,
                  _textFormImc
                ],
              ),
              Row(
                children: <Widget>[
                  _textFormMuscle,
                  _textFormFat
                ],
              ),
              Center(
                child: Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: RaisedButton(
                    child: Text('Guardar medición'),
                    onPressed: () {
                      _submitForm();
                    },
                  ),
                ),
              )
            ],

          ),
        ),
      ),
    );
  }

  Widget _getTextField(String label, FocusNode currentFocusNode, FocusNode nextFocusNode, TextEditingController currentController, TextEditingController nextController) {
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: TextFormField(
          decoration: InputDecoration(
              labelText: label
          ),
          keyboardType: TextInputType.number,
          validator: (value) {
            if (value.isEmpty) {
              return 'Campo necesario';
            }
            return null;
          },
          focusNode: currentFocusNode,
          controller: currentController,
          onFieldSubmitted: (term) {
            if(nextController.text.isEmpty){
              _fieldFocusChange(context, currentFocusNode, nextFocusNode);
            }
          },
        ),
      ),
    );
  }

  _fieldFocusChange(BuildContext context, FocusNode currentFocus, FocusNode nextFocus) {
    currentFocus.unfocus();
    FocusScope.of(context).requestFocus(nextFocus);
  }

  _submitForm() {
    if (_formKey.currentState.validate()) {
      Indicator indicator = Indicator(
        weight: double.parse(this._weightController.text),
        imc: double.parse(this._imcController.text),
        muscle: double.parse(this._muscleController.text),
        fat: double.parse(this._fatController.text),
        dateTime: DateTime.now().toIso8601String()
      );
      bloc.saveIndicator(indicator);
      Navigator.pop(context);
    }
  }
}